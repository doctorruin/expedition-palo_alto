-- MySQL dump 10.16  Distrib 10.1.33-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pandbRBAC
-- ------------------------------------------------------
-- Server version	10.1.33-MariaDB-1~xenial

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activations`
--

DROP TABLE IF EXISTS `activations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activations`
--

LOCK TABLES `activations` WRITE;
/*!40000 ALTER TABLE `activations` DISABLE KEYS */;
INSERT INTO `activations` VALUES (1,1,'CZ7PnoTpD7pZJUzrh3c5QqHUN0ELijot',1,'2016-03-21 23:25:26','2016-03-21 23:25:26','2016-03-21 23:25:26');
/*!40000 ALTER TABLE `activations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditlogs`
--

DROP TABLE IF EXISTS `auditlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditlogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL,
  `level` int(11) NOT NULL,
  `task` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `action` text NOT NULL,
  `fixed` int(1) NOT NULL DEFAULT '0',
  `datetime` datetime NOT NULL,
  `obj_type` varchar(75) NOT NULL,
  `obj_id` int(11) NOT NULL,
  `obj_table` varchar(75) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `index1` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditlogs`
--

LOCK TABLES `auditlogs` WRITE;
/*!40000 ALTER TABLE `auditlogs` DISABLE KEYS */;
INSERT INTO `auditlogs` VALUES (1,'login',1,'Login','User:admin logged in at:Sun, 20 May 2018 09:40:38 +0200','',0,'2018-05-20 02:40:38','',0,''),(2,'login',1,'Login','User:admin logged in at:Sun, 20 May 2018 11:03:58 +0200','',0,'2018-05-20 04:03:58','',0,''),(3,'login',1,'Login','User:admin logged in at:Fri, 15 Mar 2019 18:33:16 +0100','',0,'2019-03-15 12:33:16','',0,''),(4,'login',1,'Login','User:admin logged in at:Fri, 15 Mar 2019 20:18:15 +0100','',0,'2019-03-15 14:18:15','',0,'');
/*!40000 ALTER TABLE `auditlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `curlConnections`
--

DROP TABLE IF EXISTS `curlConnections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `curlConnections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `origin` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `hostedConnections` int(11) NOT NULL DEFAULT '0',
  `status` varchar(45) NOT NULL DEFAULT 'Invalid',
  `created_at` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `connectionPos` varchar(255) NOT NULL,
  `connection` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `curlConnections`
--

LOCK TABLES `curlConnections` WRITE;
/*!40000 ALTER TABLE `curlConnections` DISABLE KEYS */;
/*!40000 ALTER TABLE `curlConnections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_keys`
--

DROP TABLE IF EXISTS `device_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `key_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `api_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` varchar(45) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'admin',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_keys`
--

LOCK TABLES `device_keys` WRITE;
/*!40000 ALTER TABLE `device_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_logs`
--

DROP TABLE IF EXISTS `device_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_serial` varchar(255) NOT NULL,
  `log_name` text NOT NULL,
  `date` datetime NOT NULL,
  `processed` datetime DEFAULT '0000-00-00 00:00:00',
  `comment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_logs`
--

LOCK TABLES `device_logs` WRITE;
/*!40000 ALTER TABLE `device_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devices` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `devicename` varchar(255) NOT NULL,
  `hostname` varchar(255) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `panos` varchar(255) NOT NULL,
  `threats` tinyint(4) NOT NULL,
  `apps` tinyint(4) NOT NULL,
  `ispanorama` tinyint(4) NOT NULL,
  `config` tinyint(4) NOT NULL,
  `serial` varchar(255) NOT NULL,
  `serialHA` text,
  `vsys` varchar(255) NOT NULL,
  `appversion` varchar(255) NOT NULL,
  `appreleasedate` datetime NOT NULL,
  `threatversion` varchar(255) NOT NULL,
  `threatreleasedate` datetime NOT NULL,
  `device` varchar(255) NOT NULL,
  `management` varchar(255) NOT NULL,
  `urldb` varchar(255) NOT NULL,
  `connected` varchar(3) NOT NULL,
  `deactivated` varchar(3) NOT NULL,
  `wildfireversion` varchar(255) NOT NULL,
  `uptime` varchar(255) NOT NULL,
  `avversion` varchar(255) DEFAULT NULL,
  `urlfilteringversion` varchar(255) DEFAULT NULL,
  `logtype` varchar(255) NOT NULL,
  `csv_path` varchar(1024) NOT NULL,
  `avoidToday` tinyint(4) NOT NULL DEFAULT '0',
  `afterProcess` varchar(45) DEFAULT 'Nothing',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `completed` int(11) DEFAULT '0',
  `failed` int(11) DEFAULT '0',
  `tasks` int(11) NOT NULL DEFAULT '0',
  `parentType` varchar(45) NOT NULL,
  `parentId` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `parentJob` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licenses`
--

DROP TABLE IF EXISTS `licenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `feature` varchar(255) DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  `expired` varchar(3) DEFAULT 'no',
  `device_id` varchar(45) DEFAULT NULL,
  `serial` varchar(255) NOT NULL,
  `baselicensename` varchar(1024) DEFAULT NULL,
  `authcode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licenses`
--

LOCK TABLES `licenses` WRITE;
/*!40000 ALTER TABLE `licenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `licenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `msg` text,
  `logCode` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml_settings`
--

DROP TABLE IF EXISTS `ml_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ml_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server` varchar(255) DEFAULT NULL,
  `parquetPath` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_settings`
--

LOCK TABLES `ml_settings` WRITE;
/*!40000 ALTER TABLE `ml_settings` DISABLE KEYS */;
INSERT INTO `ml_settings` VALUES (1,'192.168.60.129',NULL);
/*!40000 ALTER TABLE `ml_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persistences`
--

DROP TABLE IF EXISTS `persistences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `persistences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `persistences_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persistences`
--

LOCK TABLES `persistences` WRITE;
/*!40000 ALTER TABLE `persistences` DISABLE KEYS */;
INSERT INTO `persistences` VALUES (1,1,'S3nKiChyP3q2XghWwXqa9tzbdpwHhxiJ','2018-05-20 14:40:38','2018-05-20 14:40:38'),(2,1,'5qs60DWQUrrY8o66xNoMrKsGm7NHUnwv','2018-05-20 14:40:40','2018-05-20 14:40:40'),(3,1,'VuMmWyDadFhWkujsZP7rwopnJzxvuzel','2018-05-20 14:40:40','2018-05-20 14:40:40'),(4,1,'9xGH0liKRbiSLwAO05MJhWHwlErvplJ2','2018-05-20 14:40:40','2018-05-20 14:40:40'),(5,1,'Xd0xk1NbUMUjgeHbjeYLp8lc6y4mScFN','2018-05-20 14:40:40','2018-05-20 14:40:40'),(6,1,'IftepXmhGS1ZSq8cywwgU2duViKGy0OG','2018-05-20 14:40:40','2018-05-20 14:40:40'),(7,1,'t1QBDrICdOJmi52Y0TZm7TjdAQ6PPFi6','2018-05-20 14:40:40','2018-05-20 14:40:40'),(8,1,'1vT9M0IRhUUy2X5MUbV4HBGQY1mEkUbM','2018-05-20 14:40:40','2018-05-20 14:40:40'),(9,1,'milJP53aeE4WJcbV2C9P32Wy3rj1tL34','2018-05-20 14:40:40','2018-05-20 14:40:40'),(10,1,'T0dMLXc3Yz2tJwUYWGDvLRHxRVix0EUo','2018-05-20 14:40:40','2018-05-20 14:40:40'),(11,1,'GbBPevv5nVXj4YJpswxIq1s4aN6aHKfo','2018-05-20 14:40:40','2018-05-20 14:40:40'),(12,1,'4Uz9xEXPUvFyiliJOJPhrGzycIARnsGG','2018-05-20 14:40:40','2018-05-20 14:40:40'),(13,1,'LM6rusy5dwK38P9DdfTQF3OJBSsK8sho','2018-05-20 16:03:58','2018-05-20 16:03:58'),(14,1,'9jNLSUleWww6GOIPhsUQjxs2JNS6nGJE','2018-05-20 16:04:00','2018-05-20 16:04:00'),(15,1,'BCpNW7aF7GAPRUI5wva9rBYzbIDFh5xq','2018-05-20 16:04:01','2018-05-20 16:04:01'),(16,1,'6GGOws4t41216mMIJIWV34XWSTKLage1','2018-05-20 16:04:01','2018-05-20 16:04:01'),(17,1,'Hw9eAB0sPZlrKsWuJQNCSnvvA8Mk9cQ4','2018-05-20 16:04:01','2018-05-20 16:04:01'),(18,1,'gf8ELjMYKbzsF6NSlsLqK0zRyv9x7R1x','2018-05-20 16:04:01','2018-05-20 16:04:01'),(19,1,'gBFV5dkJNo3kahTJARo9X2vtUmbl6jgI','2018-05-20 16:04:01','2018-05-20 16:04:01'),(20,1,'l5OiksMUfMXtbhGdB5kEXZu40HGTpHPr','2018-05-20 16:04:01','2018-05-20 16:04:01'),(21,1,'gfX0WMo9H3aPKxedbfaZfKIDMv4nkQlS','2018-05-20 16:04:01','2018-05-20 16:04:01'),(22,1,'okn6wifz7Q1nFvaCsUc4QFz26mxvneMP','2018-05-20 16:04:01','2018-05-20 16:04:01'),(23,1,'WLv2TiqU7bKEXa1rnDWLP3D54mUj2wl8','2018-05-20 16:04:01','2018-05-20 16:04:01'),(24,1,'DJuLR7gOTHItD5WnKwJhr6k7wXB9ZSCt','2018-05-20 16:04:01','2018-05-20 16:04:01'),(25,1,'5HqPlYk8BHiU1Xt26vgI0jXttFzftUSX','2018-05-20 16:04:51','2018-05-20 16:04:51'),(26,1,'63s7iRyxZS9SZxAy3iQe0ew0kDIQzfTT','2018-05-20 16:04:54','2018-05-20 16:04:54'),(27,1,'5PDT2BGnJKvdfVMW0BbcC25WOrkZE4Bp','2018-05-20 16:04:54','2018-05-20 16:04:54'),(28,1,'MRhtjPPAZfj0D6JgDP40UsHxitiQD2Rc','2018-05-20 16:06:55','2018-05-20 16:06:55'),(29,1,'vjW6RsItCkMgrCV2FXjA7nClPfH5DRI3','2018-05-20 16:06:55','2018-05-20 16:06:55'),(30,1,'zel6oTLtUWELKt7nAhucvMWb5i7GbEKf','2018-05-20 16:06:55','2018-05-20 16:06:55'),(31,1,'8biNvFkdpg4UZ2ljtMHgxqVzydHiwjCI','2018-05-20 16:06:55','2018-05-20 16:06:55'),(32,1,'ir6wmRiJ6Nb9LXWTytmI4ccK6SlN0rnh','2018-05-20 16:06:55','2018-05-20 16:06:55'),(33,1,'PMNpDq64L646pOGoT2Ee227BR6WcDh7a','2018-05-20 16:07:02','2018-05-20 16:07:02'),(34,1,'7xca8edN8G70pcndxaEd6KyPvVegcvl5','2018-05-20 16:07:03','2018-05-20 16:07:03'),(35,1,'ymcmbMsxyBkHNcEn8gREHpcdcdSfU9rv','2019-03-15 23:33:16','2019-03-15 23:33:16'),(36,1,'AqBRBtgZi9dUxdBqbLrqLBmRyO82rddX','2019-03-15 23:33:17','2019-03-15 23:33:17'),(37,1,'Hm6svS2XevWUM1uFJsQY0bVrfDT7O7sD','2019-03-15 23:33:18','2019-03-15 23:33:18'),(38,1,'qpKOn7V3GI9iiAaPkrm4jVlna039V2k3','2019-03-15 23:33:18','2019-03-15 23:33:18'),(39,1,'ySbimOE1Cr61qtIGU8hhxzsFGWvj4Dul','2019-03-15 23:33:18','2019-03-15 23:33:18'),(40,1,'jMHkMUmPCekciGMuZ6iRcPDHbIuJIkHp','2019-03-15 23:33:18','2019-03-15 23:33:18'),(41,1,'IZ6kahY64wck4yL6BVLlqP0GT7ZDm9Wm','2019-03-15 23:33:19','2019-03-15 23:33:19'),(42,1,'6GfktXQBN2DqpHzVI9JQz025Grwfc0ML','2019-03-15 23:33:19','2019-03-15 23:33:19'),(43,1,'ymZXjwYP6fU18JbHTRI20STX0hziiMn2','2019-03-15 23:33:19','2019-03-15 23:33:19'),(44,1,'R5BDDlPi7AMvkFE35vP9IaHJMpcmQMxN','2019-03-15 23:33:19','2019-03-15 23:33:19'),(45,1,'IV3otVk1LRZ3iKyNTkesuyeAbkYg0FUk','2019-03-15 23:33:19','2019-03-15 23:33:19'),(46,1,'cy2pfXPyrnyZ9M9DyPbTa5QNStSH29qN','2019-03-15 23:33:19','2019-03-15 23:33:19'),(47,1,'pYtKK4Eo43XYGgYaTaWeNGf3M31o5voQ','2019-03-15 23:33:19','2019-03-15 23:33:19'),(48,1,'JNxJ3YiEJPV7Jtb3PU0Hi8E6EQnsUk1v','2019-03-15 23:35:23','2019-03-15 23:35:23'),(49,1,'dvnb4TCxd1iKNCrmg13DOwuo12PCVbW4','2019-03-15 23:35:24','2019-03-15 23:35:24'),(50,1,'u0rTr8ndi0bZUa4P7lU8GBRPIOkozElV','2019-03-15 23:35:24','2019-03-15 23:35:24'),(51,1,'dUiOas34YnMamenKHDD4IAaPW0dEHXXt','2019-03-15 23:35:24','2019-03-15 23:35:24'),(52,1,'mZEvxca1CQKDBhgOr6Dw1NKHrMwutKAA','2019-03-15 23:35:24','2019-03-15 23:35:24'),(53,1,'ingkwmszgyzlyTEsUpAXQo98GUtmGUfj','2019-03-15 23:35:24','2019-03-15 23:35:24'),(54,1,'sVwTFxQHhik3Jld9pV8Xtkf6huLPXquh','2019-03-15 23:35:25','2019-03-15 23:35:25'),(55,1,'dSXrTAR91f7g7ZLkDxVDi395SbItvB62','2019-03-15 23:35:25','2019-03-15 23:35:25'),(56,1,'iiydE99m3YVzOEQB6lNAvnDoWZhKzJ45','2019-03-15 23:35:25','2019-03-15 23:35:25'),(57,1,'GzjQmpJwgR4PNuCNKws8B8gHe6kR2sOw','2019-03-15 23:35:25','2019-03-15 23:35:25'),(58,1,'4zumtGkbLLOQDiXu6BZxlOVJHb8IuFPT','2019-03-15 23:35:25','2019-03-15 23:35:25'),(59,1,'R9HQiRRTwEHIHmInKWwxyO84uRsUQHGs','2019-03-15 23:35:25','2019-03-15 23:35:25'),(60,1,'9JbJexLjlISqTUFpVCnc8A1V1rIwAyuR','2019-03-15 23:35:32','2019-03-15 23:35:32'),(61,1,'Kntvy5yBn3v9zUchKjTtYNR5TYtkR3hX','2019-03-15 23:35:33','2019-03-15 23:35:33'),(62,1,'0TJ81ubQKYepuC7tObS5DtSHy4DPNYnJ','2019-03-15 23:35:33','2019-03-15 23:35:33'),(63,1,'9NQqBqPcdLjmeDcJxRPDPTjXbWPAC8uk','2019-03-15 23:35:33','2019-03-15 23:35:33'),(64,1,'aM21YdJrQLhuHW1Ij80r37fQLLI1jRwg','2019-03-15 23:35:33','2019-03-15 23:35:33'),(65,1,'vEDTMt2BlLAMKfY9B1TaPGlBKXW0PaeV','2019-03-15 23:35:33','2019-03-15 23:35:33'),(66,1,'s7U25y1IluU08F2PnCe3ngvPf56JBhUD','2019-03-15 23:35:33','2019-03-15 23:35:33'),(67,1,'eZswy5dBm0hoRv7V3vdZQQTEpvE5TeuU','2019-03-15 23:35:33','2019-03-15 23:35:33'),(68,1,'fkP5Xj1EI9bxEUWlGmFe6X4TT1xbTqhW','2019-03-15 23:35:33','2019-03-15 23:35:33'),(69,1,'rch3T1385ILyGoWxq8BFzCGQlncSltLc','2019-03-15 23:35:33','2019-03-15 23:35:33'),(70,1,'BFBoaseW5A2uxVN2ACl5gIddIEheEezB','2019-03-15 23:35:33','2019-03-15 23:35:33'),(71,1,'cf6GV6u6aybdkRc2s6lLMsG8EfTz2oX1','2019-03-15 23:35:33','2019-03-15 23:35:33'),(72,1,'uwpwJqGma72oVtyp6mcuHnli708T2dEn','2019-03-15 23:41:48','2019-03-15 23:41:48'),(73,1,'GknVUgZZ9bqsGiLztz43DiFs1gtBTevo','2019-03-16 01:18:15','2019-03-16 01:18:15'),(74,1,'Lvfx6qb1fDMrYsUBRgsdY1h7saogqCIx','2019-03-16 01:18:16','2019-03-16 01:18:16'),(75,1,'rqVz0unxc3iXICEFO7O3WvecrhDfLYvB','2019-03-16 01:18:18','2019-03-16 01:18:18'),(76,1,'Sv541rAurcVpoD8zoeOzlUJicxLAp0lu','2019-03-16 01:18:18','2019-03-16 01:18:18'),(77,1,'SXUo5XjIAbVFliV3jmapmhaY7yWfiJ1n','2019-03-16 01:18:18','2019-03-16 01:18:18'),(78,1,'z4LLRa7QC6ksqHJWxBVQvlHp2I65W7Bh','2019-03-16 01:18:22','2019-03-16 01:18:22'),(79,1,'VJevtvdWtXYTq3O6oPAaNVV4YZK4I8E2','2019-03-16 01:18:22','2019-03-16 01:18:22'),(80,1,'8R9ZVoxHEgnkfQJyrmglFwLaDMh36Va0','2019-03-16 01:18:22','2019-03-16 01:18:22'),(81,1,'79Z1DR04ZC1chDsFkqdGHQwDgsvCmAsu','2019-03-16 01:18:22','2019-03-16 01:18:22'),(82,1,'IEwgqJaWsVKL6fX8OtGdbPFnjfVWXfJ7','2019-03-16 01:18:22','2019-03-16 01:18:22'),(83,1,'Zled3GRLXayNpjfpl2CO6WKUhFzC8do1','2019-03-16 01:18:25','2019-03-16 01:18:25'),(84,1,'qSRIHKrYtxaerLlrPq35DT9j9UMguHlV','2019-03-16 01:18:25','2019-03-16 01:18:25'),(85,1,'HnjgpokSOlqVMFtOGzJOPwC1lpHo37NS','2019-03-16 01:18:25','2019-03-16 01:18:25');
/*!40000 ALTER TABLE `persistences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_devices`
--

DROP TABLE IF EXISTS `project_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_devices` (
  `project_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `device_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `selectedBy` tinytext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`project_name`,`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_devices`
--

LOCK TABLES `project_devices` WRITE;
/*!40000 ALTER TABLE `project_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `vendors` varchar(255) NOT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `progress` int(2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `appversion` varchar(255) DEFAULT NULL,
  `panos` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT 'Migration',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminders`
--

DROP TABLE IF EXISTS `reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reminders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminders`
--

LOCK TABLES `reminders` WRITE;
/*!40000 ALTER TABLE `reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remote_LDAP_server`
--

DROP TABLE IF EXISTS `remote_LDAP_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `remote_LDAP_server` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `dn` text NOT NULL,
  `admin_user` varchar(255) DEFAULT NULL,
  `admin_password` varchar(255) DEFAULT NULL,
  `ldap_type` varchar(45) DEFAULT NULL,
  `uses_ssl` tinyint(4) NOT NULL DEFAULT '0',
  `uses_tsl` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `name` varchar(45) NOT NULL,
  `account_suffix` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remote_LDAP_server`
--

LOCK TABLES `remote_LDAP_server` WRITE;
/*!40000 ALTER TABLE `remote_LDAP_server` DISABLE KEYS */;
/*!40000 ALTER TABLE `remote_LDAP_server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remote_Radius_server`
--

DROP TABLE IF EXISTS `remote_Radius_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `remote_Radius_server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) NOT NULL,
  `port` int(11) DEFAULT '1812',
  `shared_key` varchar(255) NOT NULL,
  `active` tinyint(4) DEFAULT '1',
  `name` varchar(45) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remote_Radius_server`
--

LOCK TABLES `remote_Radius_server` WRITE;
/*!40000 ALTER TABLE `remote_Radius_server` DISABLE KEYS */;
/*!40000 ALTER TABLE `remote_Radius_server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_users`
--

DROP TABLE IF EXISTS `role_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_users` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_users`
--

LOCK TABLES `role_users` WRITE;
/*!40000 ALTER TABLE `role_users` DISABLE KEYS */;
INSERT INTO `role_users` VALUES (1,3,'2016-05-31 00:44:06','2016-05-31 00:44:06');
/*!40000 ALTER TABLE `role_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','Admin','{\"project.create\":true, \"device.create\":true, \"user.update\":true}','2016-03-29 18:12:35','2016-03-29 18:12:35'),(2,'user','User','{\"user.view\":true}','2016-03-29 18:12:35','2016-03-29 18:12:35'),(3,'superuser','Super User','{\"user.create\":true,\"user.admin\":true,\"user.delete\":true, \"role.admin\":true, \"server.admin\":true, \"project.create\":true, \"project.admin\":true, \"device.admin\":true, \"expedition.admin\":true}','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security`
--

DROP TABLE IF EXISTS `security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `lid` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `iv` varchar(45) NOT NULL DEFAULT 'l3tsB3$str0ng,a!',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security`
--

LOCK TABLES `security` WRITE;
/*!40000 ALTER TABLE `security` DISABLE KEYS */;
/*!40000 ALTER TABLE `security` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sparkJobs`
--

DROP TABLE IF EXISTS `sparkJobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sparkJobs` (
  `taskID` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `message` text,
  `timestamp` datetime DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sparkJobs`
--

LOCK TABLES `sparkJobs` WRITE;
/*!40000 ALTER TABLE `sparkJobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `sparkJobs` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger update_job
after insert
 on pandbRBAC.sparkJobs for each row
begin
  update pandbRBAC.tasks set statusCode=IF(NEW.status='completed',1,IF(NEW.status='start',0.1,-1)),
                             statusMessage=NEW.message,
                             updated_at = NOW()
  where id=NEW.taskID;

  update pandbRBAC.jobs set completed=completed+ IF(NEW.status='completed' OR NEW.status='failed',1,0),
                            failed=failed+ IF(NEW.status='failed',1,0)
  where id=(select job_id
            from pandbRBAC.tasks
            where id=NEW.taskID);
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `taskType` varchar(45) NOT NULL,
  `processCode` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `statusCode` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `statusMessage` varchar(255) NOT NULL DEFAULT '',
  `taskName` varchar(255) NOT NULL DEFAULT 'Remote Task',
  `resultCode` varchar(255) DEFAULT NULL,
  `retry` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `throttle`
--

DROP TABLE IF EXISTS `throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `throttle_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `throttle`
--

LOCK TABLES `throttle` WRITE;
/*!40000 ALTER TABLE `throttle` DISABLE KEYS */;
/*!40000 ALTER TABLE `throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `updates`
--

DROP TABLE IF EXISTS `updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `updates`
--

LOCK TABLES `updates` WRITE;
/*!40000 ALTER TABLE `updates` DISABLE KEYS */;
INSERT INTO `updates` VALUES (1,'2018-05-20 02:22:04','20171113_001_alter_table_devices_logs.pandbRBAC'),(2,'2018-05-20 02:22:04','20171128_001_create_table_security.pandbRBAC'),(3,'2018-05-20 02:22:04','20171219_004_create_procedure_updateJobs.pandbRBAC'),(4,'2018-05-20 02:22:04','20180206_002_update_role_User.pandbRBAC'),(5,'2018-05-20 02:22:04','20180219_001_update_role_Admin.pandbRBAC'),(6,'2018-05-20 02:22:04','20180322_001_add_table_logs.pandbRBAC'),(7,'2018-05-20 02:22:04','20180327_001.replacelog_auditlog.pandbRBAC'),(8,'2018-05-20 02:22:04','20180404_001_alter_table_tasks.pandbRBAC'),(9,'2018-09-22 02:55:18','20180607_001_alter_devices.pandbRBAC'),(10,'2018-09-22 02:55:18','20180608_001_alter_devices.pandbRBAC');
/*!40000 ALTER TABLE `updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_settings`
--

DROP TABLE IF EXISTS `user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `project_id` int(11) unsigned DEFAULT NULL,
  `selectedDevices` tinytext,
  `panos_vsys` varchar(45) DEFAULT NULL,
  `source` int(11) unsigned DEFAULT NULL,
  `panorama_template` int(11) unsigned DEFAULT NULL,
  `view` varchar(45) DEFAULT NULL,
  `panorama_rules` varchar(45) DEFAULT NULL,
  `selectedLogConnector` int(11) DEFAULT NULL,
  `selectedUIDConnector` int(11) DEFAULT NULL,
  `version` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_settings`
--

LOCK TABLES `user_settings` WRITE;
/*!40000 ALTER TABLE `user_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `last_login` timestamp NULL DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `location_id` int(10) NOT NULL DEFAULT '0',
  `location_type` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `timezone` varchar(60) CHARACTER SET utf8 NOT NULL,
  `active` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2y$10$Nk2/jJmmirfgfLLPEGJ7.erkiaVCgRGUZvSPi5wG/gg8SqYFBvYPO',NULL,'2019-03-16 01:18:25','adminim','Migration Tool admin us','2016-03-29 21:10:39','2019-03-16 01:18:25',0,'local','Europe/Amsterdam',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-16 15:05:47
